// Gambit Signup by Keiltas - Background Service Worker
// This script handles background operations and notifications

// Listen for extension installation
chrome.runtime.onInstalled.addListener(() => {
  console.log('Gambit Signup by Keiltas extension installed');
  
  // Set default state
  chrome.storage.local.set({ isActive: false });
});

// Listen for messages from content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'SIGNUP_SUCCESS') {
    // Create a notification
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: 'Gambit Signup by Keiltas',
      message: `Successfully signed up for a raid led by ${message.leader}!`,
      priority: 2
    });
    
    // Add a badge to show success
    chrome.action.setBadgeText({ text: '✓' });
    chrome.action.setBadgeBackgroundColor({ color: '#4CAF50' });
    
    // Clear the badge after 10 seconds
    setTimeout(() => {
      chrome.action.setBadgeText({ text: '' });
    }, 10000);
  }
});

// Listen for tab updates to monitor when on the Nova Boosting site
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url.includes('novaboosting.com')) {
    // Check if we should be monitoring
    chrome.storage.local.get('isActive', (result) => {
      if (result.isActive) {
        // Update the icon to show we're active on this site
        chrome.action.setIcon({
          tabId: tabId,
          path: {
            16: 'icons/icon16_active.png',
            48: 'icons/icon48_active.png',
            128: 'icons/icon128_active.png'
          }
        });
      }
    });
  }
});