// Gambit Signup by Keiltas - Content Script
// This script monitors the Nova Boosting website for raids and auto-signs up when the specified leader is found

// Configuration state
let config = null;
let isMonitoring = false;
let checkInterval = null;
let signedUpRaids = new Set();
let processingRaidId = null;
let successSound = null;
let currentPage = 1;
let maxPages = Infinity;

// Initialize the extension
function initialize() {
    // Listen for messages from popup
    window.addEventListener('message', (event) => {
        if (event.data.type === 'NOVA_BOOSTER_START') {
            config = event.data.config;
            startMonitoring();
        } else if (event.data.type === 'NOVA_BOOSTER_STOP') {
            stopMonitoring();
        }
    });

    // Check if we should be monitoring (in case of page refresh)
    chrome.storage.local.get(['isActive', 'leaderName', 'playerClass', 'playerRole', 'saved', 'note', 'logsLink', 'alt', 'signedUpRaidIds'], (result) => {
        if (result.isActive) {
            config = {
                leaderName: result.leaderName,
                playerClass: result.playerClass,
                playerRole: result.playerRole,
                saved: result.saved,
                note: result.note,
                logsLink: result.logsLink,
                alt: result.alt
            };
            if (result.signedUpRaidIds) {
                signedUpRaids = new Set(result.signedUpRaidIds);
            }
            startMonitoring();
        }
    });

    // Initialize success sound
    successSound = new Audio(chrome.runtime.getURL('success.mp3'));
}

// Start monitoring for raids
function startMonitoring() {
    if (isMonitoring) return;

    console.log('Gambit Signup: Started monitoring for raids...');
    isMonitoring = true;
    currentPage = 1;
    maxPages = Infinity;
    checkInterval = setInterval(findAndSignUpForRaids, 5000);
}

// Stop monitoring for raids
function stopMonitoring() {
    if (!isMonitoring) return;

    console.log('Gambit Signup: Stopped monitoring.');
    isMonitoring = false;
    clearInterval(checkInterval);
}

function findAndSignUpForRaids() {
    if (processingRaidId) {
        console.log(`Currently processing raid ${processingRaidId}, skipping.`);
        return;
    }

    if (currentPage > maxPages) {
        console.log("Reached the last page. Stopping.");
        stopMonitoring();
        return;
    }

    const raidElements = document.querySelectorAll('.cubox');
    let nextRaidToSignUp = null;

    raidElements.forEach(raidElement => {
        const leaderElement = raidElement.querySelector('li.cubox-item span a');
        if (!leaderElement) return;

        const leaderName = leaderElement.textContent.trim();
        if (leaderName === config.leaderName) {
            const signUpButton = raidElement.querySelector('button.custom-btn.btn-green');
            const raidIdMatch = signUpButton.getAttribute('data-target').match(/#signModal(\d+)/);
            if (!raidIdMatch) return;
            const raidId = raidIdMatch[1];

            if (signUpButton && !signedUpRaids.has(raidId)) {
                if (!nextRaidToSignUp) {
                    nextRaidToSignUp = { button: signUpButton, id: raidId };
                }
            }
        }
    });

    if (nextRaidToSignUp) {
        console.log(`Found matching raid by ${config.leaderName} with ID: ${nextRaidToSignUp.id}, attempting signup...`);
        processingRaidId = nextRaidToSignUp.id;
        attemptSignUpForRaid(nextRaidToSignUp.button, nextRaidToSignUp.id);
        return;
    } else {
        console.log(`No matching and available raids found on page ${currentPage}.`);
    }

    const nextPageButton = findNextPageButton();
    if (nextPageButton) {
        currentPage++;
        console.log(`Navigating to next page: ${currentPage}`);
        nextPageButton.click();
        setTimeout(findAndSignUpForRaids, 3000);
    } else {
        maxPages = currentPage;
        console.log("No next page button found.");
    }
}

function findNextPageButton() {
    const nextButton = document.querySelector('ul.pagination li.active + li a');
    return nextButton;
}

function attemptSignUpForRaid(signUpButton, raidId) {
    if (!signUpButton) {
        console.warn('Signup button not found.');
        processingRaidId = null;
        return;
    }

    signUpButton.click();

    setTimeout(() => {
        const form = document.querySelector(`#signModal${raidId} form`);
        if (!form) {
            console.warn('Signup form not found.');
            closeModal(raidId);
            processingRaidId = null;
            return;
        }

        const classSelect = form.querySelector('select[name="class"]');
        const roleSelect = form.querySelector('select[name="role"]');
        const savedRadio = form.querySelector(`input[name="saved"][value="${config.saved}"]`);
        const noteInput = form.querySelector('input[name="note"]');
        const logsLinkInput = form.querySelector('input[name="logs_link"]');
        const altCheckbox = form.querySelector('input[name="altsign"]');
        const altNameInput = form.querySelector('input[name="alt_name"]');

        if (classSelect) classSelect.value = config.playerClass;
        if (roleSelect) roleSelect.value = config.playerRole;
        if (savedRadio) savedRadio.click();
        if (noteInput) noteInput.value = config.note;
        if (logsLinkInput) logsLinkInput.value = config.logsLink;
        if (altCheckbox) altCheckbox.checked = config.alt;
        if (altNameInput) {
            altNameInput.style.display = config.alt ? 'block' : 'none';
            if (config.alt) altNameInput.value = config.altName;
        }

        form.submit();
        console.log('Submitted signup form. Waiting for response...');

        // *** WAIT AND THEN CHECK FOR ERROR ***
        setTimeout(() => {
            const errorMessageElement = document.querySelector('.alert.alert-danger'); // Adjust selector if needed
            if (errorMessageElement && errorMessageElement.textContent.includes('You only can sign once for each raid')) {
                console.log('Detected "already signed up" error.');
                closeModal(raidId);
                showNotification('You have already signed up for this raid.', false);
                processingRaidId = null;
                return;
            }

            // If no error, proceed with success
            signedUpRaids.add(raidId);
            chrome.storage.local.set({ signedUpRaidIds: Array.from(signedUpRaids) });

            if (successSound) successSound.play();
            showNotification('Successfully signed up for the raid!', true);

            processingRaidId = null;

        }, 2000);  // Adjust this timeout as needed!

    }, 500);
}

function closeModal(raidId) {
    const closeButton = document.querySelector(`#signModal${raidId} .close`);
    if (closeButton) {
        closeButton.click();
    }
}

function showNotification(message, isSuccess) {
    let notificationContainer = document.getElementById('nova-booster-notification');

    if (!notificationContainer) {
        notificationContainer = document.createElement('div');
        notificationContainer.id = 'nova-booster-notification';
        notificationContainer.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            max-width: 300px;
            padding: 12px 16px;
            background-color: #333;
            color: white;
            border-radius: 6px;
            font-family: 'Segoe UI', 'Roboto', sans-serif;
            font-size: 14px;
            z-index: 10000;
            transition: all 0.3s ease;
            opacity: 0;
            transform: translateY(20px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        `;
        document.body.appendChild(notificationContainer);
    }

    notificationContainer.textContent = message;

    if (isSuccess) {
        notificationContainer.style.backgroundColor = '#4caf50';
        notificationContainer.style.borderLeft = '4px solid #388e3c';
    } else {
        notificationContainer.style.backgroundColor = '#333';
        notificationContainer.style.borderLeft = '4px solid #0074e4';
    }

    notificationContainer.style.opacity = 1;
    notificationContainer.style.transform = 'translateY(0)';

    setTimeout(() => {
        notificationContainer.style.opacity = 0;
        notificationContainer.style.transform = 'translateY(20px)';
        setTimeout(() => {
            if (notificationContainer) {
                notificationContainer.remove();
            }
        }, 300);
    }, 3000);
}

initialize();