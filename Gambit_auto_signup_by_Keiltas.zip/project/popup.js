// Template management functions
async function loadTemplates() {
  const { templates = {} } = await chrome.storage.local.get('templates');
  const select = document.getElementById('templateSelect');
  
  // Clear existing options except the first one
  while (select.options.length > 1) {
    select.remove(1);
  }
  
  // Add saved templates
  for (const [name, _] of Object.entries(templates)) {
    const option = new Option(name, name);
    select.add(option);
  }
}

async function saveCurrentTemplate() {
  const templateName = prompt('Enter a name for this template:');
  if (!templateName) return;

  const template = {
    leaderName: document.getElementById('leaderName').value.trim(),
    playerClass: document.getElementById('classSelect').value,
    playerRole: document.getElementById('roleSelect').value,
    saved: document.getElementById('savedSelect').value,
    note: document.getElementById('noteInput').value.trim(),
    logsLink: document.getElementById('logsLink').value.trim(),
    alt: document.getElementById('altSelect').value
  };

  const { templates = {} } = await chrome.storage.local.get('templates');
  templates[templateName] = template;
  
  await chrome.storage.local.set({ templates });
  await loadTemplates();

  // Set selected template to the newly created one
  document.getElementById('templateSelect').value = templateName;
  
  showNotification('Template saved successfully!');
}

async function loadSelectedTemplate() {
  const templateName = document.getElementById('templateSelect').value;
  if (!templateName) return;

  const { templates = {} } = await chrome.storage.local.get('templates');
  const template = templates[templateName];
  
  if (template) {
    document.getElementById('leaderName').value = template.leaderName || '';
    document.getElementById('classSelect').value = template.playerClass || 'Demon Hunter';
    document.getElementById('roleSelect').value = template.playerRole || 'Damage';
    document.getElementById('savedSelect').value = template.saved || 'No';
    document.getElementById('noteInput').value = template.note || '';
    document.getElementById('logsLink').value = template.logsLink || '';
    document.getElementById('altSelect').value = template.alt || 'No';
    
    updateClassColor();
    showNotification('Template loaded!');
  }
}

async function deleteSelectedTemplate() {
  const templateName = document.getElementById('templateSelect').value;
  if (!templateName) return;

  if (confirm(`Delete template "${templateName}"?`)) {
    const { templates = {} } = await chrome.storage.local.get('templates');
    delete templates[templateName];
    
    await chrome.storage.local.set({ templates });
    await loadTemplates();
    document.getElementById('templateSelect').value = '';
    showNotification('Template deleted!');
  }
}

// Helper functions
function showNotification(message, isError = false) {
  const status = document.getElementById('statusIndicator');
  status.textContent = message;
  status.style.color = isError ? 'var(--error)' : 'var(--success)';
  
  setTimeout(() => {
    status.textContent = document.getElementById('startButton').classList.contains('active') 
      ? 'Actively monitoring for raids...' 
      : 'Not monitoring';
    status.style.color = document.getElementById('startButton').classList.contains('active')
      ? 'var(--success)'
      : 'var(--text-secondary)';
  }, 3000);
}

function updateClassColor() {
  const classSelect = document.getElementById('classSelect');
  const selectedClass = classSelect.value;
  
  // WoW class colors
  const classColors = {
    'Demon Hunter': '#A330C9',
    'Death Knight': '#C41E3A',
    'Druid': '#FF7C0A',
    'Hunter': '#AAD372',
    'Mage': '#3FC7EB',
    'Monk': '#00FF98',
    'Paladin': '#F48CBA',
    'Priest': '#FFFFFF',
    'Rogue': '#FFF468',
    'Shaman': '#0070DD',
    'Warrior': '#C69B6D',
    'Warlock': '#8788EE',
    'Evoker': '#33937F'
  };
  
  classSelect.style.borderLeftWidth = '4px';
  classSelect.style.borderLeftColor = classColors[selectedClass] || 'var(--border-color)';
}

// Check if we're actively monitoring
async function checkActiveStatus() {
  const { isActive = false } = await chrome.storage.local.get('isActive');
  const startButton = document.getElementById('startButton');
  const statusIndicator = document.getElementById('statusIndicator');
  
  if (isActive) {
    startButton.textContent = 'Stop Auto Signup';
    startButton.classList.add('active');
    startButton.style.background = 'linear-gradient(to right, var(--error), #d32f2f)';
    statusIndicator.textContent = 'Actively monitoring for raids...';
    statusIndicator.classList.add('active', 'pulse');
  } else {
    startButton.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"></path><path d="M12 5l7 7-7 7"></path></svg> Start Auto Signup';
    startButton.classList.remove('active');
    startButton.style.background = 'linear-gradient(to right, var(--primary), var(--accent))';
    statusIndicator.textContent = 'Not monitoring';
    statusIndicator.classList.remove('active', 'pulse');
  }
}

// Initialize the popup
document.addEventListener('DOMContentLoaded', async () => {
  // Load saved templates
  await loadTemplates();
  
  // Setup class color indicator
  document.getElementById('classSelect').addEventListener('change', updateClassColor);
  
  // Check active monitoring status
  await checkActiveStatus();
  
  // Load last used settings if available
  const lastSettings = await chrome.storage.local.get([
    'leaderName', 'playerClass', 'playerRole', 'saved', 'note', 'logsLink', 'alt'
  ]);
  
  if (lastSettings.leaderName) {
    document.getElementById('leaderName').value = lastSettings.leaderName;
    document.getElementById('classSelect').value = lastSettings.playerClass || 'Demon Hunter';
    document.getElementById('roleSelect').value = lastSettings.playerRole || 'Damage';
    document.getElementById('savedSelect').value = lastSettings.saved || 'No';
    document.getElementById('noteInput').value = lastSettings.note || '';
    document.getElementById('logsLink').value = lastSettings.logsLink || '';
    document.getElementById('altSelect').value = lastSettings.alt || 'No';
    updateClassColor();
  }

  // Set up event listeners
  document.getElementById('loadTemplate').addEventListener('click', loadSelectedTemplate);
  document.getElementById('saveTemplate').addEventListener('click', saveCurrentTemplate);
  document.getElementById('deleteTemplate').addEventListener('click', deleteSelectedTemplate);
  
  // Start/Stop button listener
  document.getElementById('startButton').addEventListener('click', async () => {
    const leaderName = document.getElementById('leaderName').value.trim();
    
    if (!leaderName) {
      showNotification('Please enter a raid leader name!', true);
      return;
    }
    
    const playerClass = document.getElementById('classSelect').value;
    const playerRole = document.getElementById('roleSelect').value;
    const saved = document.getElementById('savedSelect').value;
    const note = document.getElementById('noteInput').value.trim();
    const logsLink = document.getElementById('logsLink').value.trim();
    const alt = document.getElementById('altSelect').value;

    // Check if we're already monitoring
    const { isActive = false } = await chrome.storage.local.get('isActive');
    
    if (isActive) {
      // Stop monitoring
      await chrome.storage.local.set({ isActive: false });
      await checkActiveStatus();
      
      // Inform content script to stop monitoring
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        function: stopSignupProcess
      });
      
      return;
    }
    
    // Save these settings as last used
    await chrome.storage.local.set({
      leaderName, playerClass, playerRole, saved, note, logsLink, alt, isActive: true
    });
    
    // Update the UI to reflect active state
    await checkActiveStatus();

    // Start the monitoring process
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (tab.url.includes('novaboosting.com')) {
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        function: startSignupProcess,
        args: [{ leaderName, playerClass, playerRole, saved, note, logsLink, alt }]
      });
    } else {
      // If not on the website, open it in a new tab
      chrome.tabs.create({ url: 'https://novaboosting.com' }, (newTab) => {
        // Wait for the page to load then inject the script
        chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
          if (tabId === newTab.id && info.status === 'complete') {
            chrome.tabs.onUpdated.removeListener(listener);
            
            chrome.scripting.executeScript({
              target: { tabId: newTab.id },
              function: startSignupProcess,
              args: [{ leaderName, playerClass, playerRole, saved, note, logsLink, alt }]
            });
          }
        });
      });
    }
  });
});

// These functions will be injected into the page
function startSignupProcess(config) {
  // Signal to content script to start monitoring
  window.postMessage({
    type: 'NOVA_BOOSTER_START',
    config: config
  }, '*');
}

function stopSignupProcess() {
  // Signal to content script to stop monitoring
  window.postMessage({
    type: 'NOVA_BOOSTER_STOP'
  }, '*');
}